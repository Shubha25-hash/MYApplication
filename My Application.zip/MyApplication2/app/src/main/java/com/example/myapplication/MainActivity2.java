package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    EditText e1,e2;
    TextView t1;
    int num1,num2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public boolean getNumbers(){
        e1=(EditText) findViewById(R.id.num1);
        e2=(EditText) findViewById(R.id.num2);
        t1=(TextView) findViewById(R.id.result);
        String s1=e1.getText().toString();
        String s2=e2.getText().toString();
        if(s1.equals(null) && s2.equals(null)||(s1.equals(" ") && s2.equals(" "))){
            String result="Please enter numbers";
            t1.setText(result);
            return false;
        }
        else{
            num1=Integer.parseInt(s1);
            num2=Integer.parseInt(s2);
        }
        return true;
    }
    public void b1(View view){

    }
    public void dosum(View view){
        if(getNumbers()){
            int sum= num1+num2;
            t1.setText(Integer.toString(sum));
        }
    }
    public void dosub(View view){
        if(getNumbers() && num1>num2) {
            int sub = num1 - num2;
            t1.setText(Integer.toString(sub));
        }
        else{
            t1.setText("num1 should be greater");
        }
    }
    public void domul(View view){
        if(getNumbers()){
            int mul=num1*num2;
            t1.setText(Integer.toString(mul));
        }
    }
    public void dodiv(View view){
        if(getNumbers()&& num2!=0){
            int div=num1/num2;
            t1.setText(Integer.toString(div));
        }
        else{
            t1.setText("zero division error");
        }
    }
    public void dopow(View view){
        if(getNumbers()){
            double p=Math.pow(num1,num2);
            t1.setText(Double.toString(p));
        }
    }
    public void domod(View view){
        if(getNumbers()){
            int m=num1%num2;
            t1.setText(Integer.toString(m));
        }
    }

}